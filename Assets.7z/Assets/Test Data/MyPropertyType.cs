﻿using System;
using UnityEngine;

[Serializable]
public class MyPropertyType
{
    public string valString;
    public int valInt;
    public Vector3 valVector3;
}
